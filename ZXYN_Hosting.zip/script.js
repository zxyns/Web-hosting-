const io=new IntersectionObserver(es=>es.forEach(e=>e.isIntersecting&&e.target.classList.add('show')),{threshold:.12});
document.querySelectorAll('.reveal').forEach(e=>io.observe(e));
document.querySelectorAll('.pricing button').forEach(b=>b.addEventListener('click',()=>alert('Plan selected — connect this button to your real billing/server API.')));
